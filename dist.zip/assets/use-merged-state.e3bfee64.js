import{ad as r,i as a}from"./index.67569da1.js";function d(u,e){return r(u,i=>{i!==void 0&&(e.value=i)}),a(()=>u.value===void 0?e.value:u.value)}export{d as u};
