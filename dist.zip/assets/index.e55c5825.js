import{d as B,h as f,c as me,a as m,b as C,e as A,f as v,u as ne,g as Y,p as q,t as J,i as z,j as ie,k as Z,r as K,o as We,l as Xe,m as Ze,n as D,q as Je,s as Se,v as Qe,w as _e,x as ce,y as He,N as Ae,z as ke,A as E,B as X,F as le,C as ue,D as eo,E as he,G as se,H as oe,I as oo,J as ye,K as ae,L as Re,M as $,O as L,P as U,Q as G,R as to,S as N,T as Pe,U as ro,V as pe,W as M,X as Q,Y as no,Z as io,_ as j,$ as lo,a0 as $e,a1 as ao,a2 as co,a3 as so,a4 as ze,a5 as uo,a6 as vo,a7 as mo,a8 as ho}from"./index.67569da1.js";import{t as po,d as fo,C as go,_ as Te,N as bo,c as xo,u as Co,r as Le,a as re,b as Ne}from"./icon.bc466e1d.js";import{u as ve}from"./use-merged-state.e3bfee64.js";import{f as de}from"./get.fc1c1a07.js";const _o=B({name:"ChevronDownFilled",render(){return f("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},f("path",{d:"M3.20041 5.73966C3.48226 5.43613 3.95681 5.41856 4.26034 5.70041L8 9.22652L11.7397 5.70041C12.0432 5.41856 12.5177 5.43613 12.7996 5.73966C13.0815 6.0432 13.0639 6.51775 12.7603 6.7996L8.51034 10.7996C8.22258 11.0668 7.77743 11.0668 7.48967 10.7996L3.23966 6.7996C2.93613 6.51775 2.91856 6.0432 3.20041 5.73966Z",fill:"currentColor"}))}}),yo={fontWeightActive:"400"},zo=e=>{const{fontSize:t,textColor3:o,textColor2:r,borderRadius:a,buttonColor2Hover:n,buttonColor2Pressed:c}=e;return Object.assign(Object.assign({},yo),{fontSize:t,itemLineHeight:"1.25",itemTextColor:o,itemTextColorHover:r,itemTextColorPressed:r,itemTextColorActive:r,itemBorderRadius:a,itemColorHover:n,itemColorPressed:c,separatorColor:o})},Io={name:"Breadcrumb",common:me,self:zo},wo=Io,So=m("breadcrumb",`
 white-space: nowrap;
 cursor: default;
 line-height: var(--n-item-line-height);
`,[C("ul",`
 list-style: none;
 padding: 0;
 margin: 0;
 `),C("a",`
 color: inherit;
 text-decoration: inherit;
 `),m("breadcrumb-item",`
 font-size: var(--n-font-size);
 transition: color .3s var(--n-bezier);
 display: inline-flex;
 align-items: center;
 `,[m("icon",`
 font-size: 18px;
 vertical-align: -.2em;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `),C("&:not(:last-child)",[A("clickable",[v("link",`
 cursor: pointer;
 `,[C("&:hover",`
 background-color: var(--n-item-color-hover);
 `),C("&:active",`
 background-color: var(--n-item-color-pressed); 
 `)])])]),v("link",`
 padding: 4px;
 border-radius: var(--n-item-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 position: relative;
 `,[C("&:hover",`
 color: var(--n-item-text-color-hover);
 `,[m("icon",`
 color: var(--n-item-text-color-hover);
 `)]),C("&:active",`
 color: var(--n-item-text-color-pressed);
 `,[m("icon",`
 color: var(--n-item-text-color-pressed);
 `)])]),v("separator",`
 margin: 0 8px;
 color: var(--n-separator-color);
 transition: color .3s var(--n-bezier);
 user-select: none;
 -webkit-user-select: none;
 `),C("&:last-child",[v("link",`
 font-weight: var(--n-font-weight-active);
 cursor: unset;
 color: var(--n-item-text-color-active);
 `,[m("icon",`
 color: var(--n-item-text-color-active);
 `)]),v("separator",`
 display: none;
 `)])])]),Me=Z("n-breadcrumb"),Ho=Object.assign(Object.assign({},Y.props),{separator:{type:String,default:"/"}}),Ao=B({name:"Breadcrumb",props:Ho,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=ne(e),r=Y("Breadcrumb","-breadcrumb",So,wo,e,t);q(Me,{separatorRef:J(e,"separator"),mergedClsPrefixRef:t});const a=z(()=>{const{common:{cubicBezierEaseInOut:c},self:{separatorColor:d,itemTextColor:s,itemTextColorHover:h,itemTextColorPressed:p,itemTextColorActive:b,fontSize:u,fontWeightActive:H,itemBorderRadius:k,itemColorHover:y,itemColorPressed:g,itemLineHeight:w}}=r.value;return{"--n-font-size":u,"--n-bezier":c,"--n-item-text-color":s,"--n-item-text-color-hover":h,"--n-item-text-color-pressed":p,"--n-item-text-color-active":b,"--n-separator-color":d,"--n-item-color-hover":y,"--n-item-color-pressed":g,"--n-item-border-radius":k,"--n-font-weight-active":H,"--n-item-line-height":w}}),n=o?ie("breadcrumb",void 0,a,e):void 0;return{mergedClsPrefix:t,cssVars:o?void 0:a,themeClass:n==null?void 0:n.themeClass,onRender:n==null?void 0:n.onRender}},render(){var e;return(e=this.onRender)===null||e===void 0||e.call(this),f("nav",{class:[`${this.mergedClsPrefix}-breadcrumb`,this.themeClass],style:this.cssVars,"aria-label":"Breadcrumb"},f("ul",null,this.$slots))}}),ko=Ze?window:null,Ro=(e=ko)=>{const t=()=>{const{hash:a,host:n,hostname:c,href:d,origin:s,pathname:h,port:p,protocol:b,search:u}=(e==null?void 0:e.location)||{};return{hash:a,host:n,hostname:c,href:d,origin:s,pathname:h,port:p,protocol:b,search:u}},o=()=>{r.value=t()},r=K(t());return We(()=>{e&&(e.addEventListener("popstate",o),e.addEventListener("hashchange",o))}),Xe(()=>{e&&(e.removeEventListener("popstate",o),e.removeEventListener("hashchange",o))}),r},Po={separator:String,href:String,clickable:{type:Boolean,default:!0},onClick:Function},$o=B({name:"BreadcrumbItem",props:Po,setup(e,{slots:t}){const o=D(Me,null);if(!o)return()=>null;const{separatorRef:r,mergedClsPrefixRef:a}=o,n=Ro(),c=z(()=>e.href?"a":"span"),d=z(()=>n.value.href===e.href?"location":null);return()=>{const{value:s}=a;return f("li",{class:[`${s}-breadcrumb-item`,e.clickable&&`${s}-breadcrumb-item--clickable`]},f(c.value,{class:`${s}-breadcrumb-item__link`,"aria-current":d.value,href:e.href,onClick:e.onClick},t),f("span",{class:`${s}-breadcrumb-item__separator`,"aria-hidden":"true"},Je(t.separator,()=>{var h;return[(h=e.separator)!==null&&h!==void 0?h:r.value]})))}}}),To=e=>{const{baseColor:t,textColor2:o,bodyColor:r,cardColor:a,dividerColor:n,actionColor:c,scrollbarColor:d,scrollbarColorHover:s,invertedColor:h}=e;return{textColor:o,textColorInverted:"#FFF",color:r,colorEmbedded:c,headerColor:a,headerColorInverted:h,footerColor:c,footerColorInverted:h,headerBorderColor:n,headerBorderColorInverted:h,footerBorderColor:n,footerBorderColorInverted:h,siderBorderColor:n,siderBorderColorInverted:h,siderColor:a,siderColorInverted:h,siderToggleButtonBorder:`1px solid ${n}`,siderToggleButtonColor:t,siderToggleButtonIconColor:o,siderToggleButtonIconColorInverted:o,siderToggleBarColor:_e(r,d),siderToggleBarColorHover:_e(r,s),__invertScrollbar:"true"}},Lo=Se({name:"Layout",common:me,peers:{Scrollbar:Qe},self:To}),Be=Lo;function No(e,t,o,r){return{itemColorHoverInverted:"#0000",itemColorActiveInverted:t,itemColorActiveHoverInverted:t,itemColorActiveCollapsedInverted:t,itemTextColorInverted:e,itemTextColorHoverInverted:o,itemTextColorChildActiveInverted:o,itemTextColorChildActiveHoverInverted:o,itemTextColorActiveInverted:o,itemTextColorActiveHoverInverted:o,itemTextColorHorizontalInverted:e,itemTextColorHoverHorizontalInverted:o,itemTextColorChildActiveHorizontalInverted:o,itemTextColorChildActiveHoverHorizontalInverted:o,itemTextColorActiveHorizontalInverted:o,itemTextColorActiveHoverHorizontalInverted:o,itemIconColorInverted:e,itemIconColorHoverInverted:o,itemIconColorActiveInverted:o,itemIconColorActiveHoverInverted:o,itemIconColorChildActiveInverted:o,itemIconColorChildActiveHoverInverted:o,itemIconColorCollapsedInverted:e,itemIconColorHorizontalInverted:e,itemIconColorHoverHorizontalInverted:o,itemIconColorActiveHorizontalInverted:o,itemIconColorActiveHoverHorizontalInverted:o,itemIconColorChildActiveHorizontalInverted:o,itemIconColorChildActiveHoverHorizontalInverted:o,arrowColorInverted:e,arrowColorHoverInverted:o,arrowColorActiveInverted:o,arrowColorActiveHoverInverted:o,arrowColorChildActiveInverted:o,arrowColorChildActiveHoverInverted:o,groupTextColorInverted:r}}const Mo=e=>{const{borderRadius:t,textColor3:o,primaryColor:r,textColor2:a,textColor1:n,fontSize:c,dividerColor:d,hoverColor:s,primaryColorHover:h}=e;return Object.assign({borderRadius:t,color:"#0000",groupTextColor:o,itemColorHover:s,itemColorActive:ce(r,{alpha:.1}),itemColorActiveHover:ce(r,{alpha:.1}),itemColorActiveCollapsed:ce(r,{alpha:.1}),itemTextColor:a,itemTextColorHover:a,itemTextColorActive:r,itemTextColorActiveHover:r,itemTextColorChildActive:r,itemTextColorChildActiveHover:r,itemTextColorHorizontal:a,itemTextColorHoverHorizontal:h,itemTextColorActiveHorizontal:r,itemTextColorActiveHoverHorizontal:r,itemTextColorChildActiveHorizontal:r,itemTextColorChildActiveHoverHorizontal:r,itemIconColor:n,itemIconColorHover:n,itemIconColorActive:r,itemIconColorActiveHover:r,itemIconColorChildActive:r,itemIconColorChildActiveHover:r,itemIconColorCollapsed:n,itemIconColorHorizontal:n,itemIconColorHoverHorizontal:h,itemIconColorActiveHorizontal:r,itemIconColorActiveHoverHorizontal:r,itemIconColorChildActiveHorizontal:r,itemIconColorChildActiveHoverHorizontal:r,itemHeight:"42px",arrowColor:a,arrowColorHover:a,arrowColorActive:r,arrowColorActiveHover:r,arrowColorChildActive:r,arrowColorChildActiveHover:r,colorInverted:"#0000",borderColorHorizontal:"#0000",fontSize:c,dividerColor:d},No("#BBB",r,"#FFF","#AAA"))},Bo=Se({name:"Menu",common:me,peers:{Tooltip:po,Dropdown:fo},self:Mo}),Fo=Bo,Fe=Z("n-layout-sider"),Oe={type:String,default:"static"},Oo=m("layout",`
 color: var(--n-text-color);
 background-color: var(--n-color);
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 flex: auto;
 overflow: hidden;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[m("layout-scroll-container",`
 overflow-x: hidden;
 box-sizing: border-box;
 height: 100%;
 `),A("absolute-positioned",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),Eo={embedded:Boolean,position:Oe,nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,onScroll:Function,contentStyle:{type:[String,Object],default:""},hasSider:Boolean,siderPlacement:{type:String,default:"left"}},Ee=Z("n-layout");function jo(e){return B({name:e?"LayoutContent":"Layout",props:Object.assign(Object.assign({},Y.props),Eo),setup(t){const o=K(null),r=K(null),{mergedClsPrefixRef:a,inlineThemeDisabled:n}=ne(t),c=Y("Layout","-layout",Oo,Be,t,a);function d(y,g){if(t.nativeScrollbar){const{value:w}=o;w&&(g===void 0?w.scrollTo(y):w.scrollTo(y,g))}else{const{value:w}=r;w&&w.scrollTo(y,g)}}q(Ee,t);let s=0,h=0;const p=y=>{var g;const w=y.target;s=w.scrollLeft,h=w.scrollTop,(g=t.onScroll)===null||g===void 0||g.call(t,y)};He(()=>{if(t.nativeScrollbar){const y=o.value;y&&(y.scrollTop=h,y.scrollLeft=s)}});const b={display:"flex",flexWrap:"nowrap",width:"100%",flexDirection:"row"},u={scrollTo:d},H=z(()=>{const{common:{cubicBezierEaseInOut:y},self:g}=c.value;return{"--n-bezier":y,"--n-color":t.embedded?g.colorEmbedded:g.color,"--n-text-color":g.textColor}}),k=n?ie("layout",z(()=>t.embedded?"e":""),H,t):void 0;return Object.assign({mergedClsPrefix:a,scrollableElRef:o,scrollbarInstRef:r,hasSiderStyle:b,mergedTheme:c,handleNativeElScroll:p,cssVars:n?void 0:H,themeClass:k==null?void 0:k.themeClass,onRender:k==null?void 0:k.onRender},u)},render(){var t;const{mergedClsPrefix:o,hasSider:r}=this;(t=this.onRender)===null||t===void 0||t.call(this);const a=r?this.hasSiderStyle:void 0,n=[this.themeClass,e&&`${o}-layout-content`,`${o}-layout`,`${o}-layout--${this.position}-positioned`];return f("div",{class:n,style:this.cssVars},this.nativeScrollbar?f("div",{ref:"scrollableElRef",class:`${o}-layout-scroll-container`,style:[this.contentStyle,a],onScroll:this.handleNativeElScroll},this.$slots):f(Ae,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,contentStyle:[this.contentStyle,a]}),this.$slots))}})}const Vo=jo(!1),Ko=m("layout-sider",`
 flex-shrink: 0;
 box-sizing: border-box;
 position: relative;
 z-index: 1;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 min-width .3s var(--n-bezier),
 max-width .3s var(--n-bezier),
 transform .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-color);
 display: flex;
 justify-content: flex-end;
`,[A("bordered",[v("border",`
 content: "";
 position: absolute;
 top: 0;
 bottom: 0;
 width: 1px;
 background-color: var(--n-border-color);
 transition: background-color .3s var(--n-bezier);
 `)]),v("left-placement",[A("bordered",[v("border",`
 right: 0;
 `)])]),A("right-placement",`
 justify-content: flex-start;
 `,[A("bordered",[v("border",`
 left: 0;
 `)]),A("collapsed",[m("layout-toggle-button",[m("base-icon",`
 transform: rotate(180deg);
 `)]),m("layout-toggle-bar",[C("&:hover",[v("top",{transform:"rotate(-12deg) scale(1.15) translateY(-2px)"}),v("bottom",{transform:"rotate(12deg) scale(1.15) translateY(2px)"})])])]),m("layout-toggle-button",`
 left: 0;
 transform: translateX(-50%) translateY(-50%);
 `,[m("base-icon",`
 transform: rotate(0);
 `)]),m("layout-toggle-bar",`
 left: -28px;
 transform: rotate(180deg);
 `,[C("&:hover",[v("top",{transform:"rotate(12deg) scale(1.15) translateY(-2px)"}),v("bottom",{transform:"rotate(-12deg) scale(1.15) translateY(2px)"})])])]),A("collapsed",[m("layout-toggle-bar",[C("&:hover",[v("top",{transform:"rotate(-12deg) scale(1.15) translateY(-2px)"}),v("bottom",{transform:"rotate(12deg) scale(1.15) translateY(2px)"})])]),m("layout-toggle-button",[m("base-icon",`
 transform: rotate(0);
 `)])]),m("layout-toggle-button",`
 transition:
 color .3s var(--n-bezier),
 right .3s var(--n-bezier),
 left .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 cursor: pointer;
 width: 24px;
 height: 24px;
 position: absolute;
 top: 50%;
 right: 0;
 border-radius: 50%;
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 18px;
 color: var(--n-toggle-button-icon-color);
 border: var(--n-toggle-button-border);
 background-color: var(--n-toggle-button-color);
 box-shadow: 0 2px 4px 0px rgba(0, 0, 0, .06);
 transform: translateX(50%) translateY(-50%);
 z-index: 1;
 `,[m("base-icon",`
 transition: transform .3s var(--n-bezier);
 transform: rotate(180deg);
 `)]),m("layout-toggle-bar",`
 cursor: pointer;
 height: 72px;
 width: 32px;
 position: absolute;
 top: calc(50% - 36px);
 right: -28px;
 `,[v("top, bottom",`
 position: absolute;
 width: 4px;
 border-radius: 2px;
 height: 38px;
 left: 14px;
 transition: 
 background-color .3s var(--n-bezier),
 transform .3s var(--n-bezier);
 `),v("bottom",`
 position: absolute;
 top: 34px;
 `),C("&:hover",[v("top",{transform:"rotate(12deg) scale(1.15) translateY(-2px)"}),v("bottom",{transform:"rotate(-12deg) scale(1.15) translateY(2px)"})]),v("top, bottom",{backgroundColor:"var(--n-toggle-bar-color)"}),C("&:hover",[v("top, bottom",{backgroundColor:"var(--n-toggle-bar-color-hover)"})])]),v("border",`
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 width: 1px;
 transition: background-color .3s var(--n-bezier);
 `),m("layout-sider-scroll-container",`
 flex-grow: 1;
 flex-shrink: 0;
 box-sizing: border-box;
 height: 100%;
 opacity: 0;
 transition: opacity .3s var(--n-bezier);
 max-width: 100%;
 `),A("show-content",[m("layout-sider-scroll-container",{opacity:1})]),A("absolute-positioned",`
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 `)]),Do=B({name:"LayoutToggleButton",props:{clsPrefix:{type:String,required:!0},onClick:Function},render(){const{clsPrefix:e}=this;return f("div",{class:`${e}-layout-toggle-button`,onClick:this.onClick},f(ke,{clsPrefix:e},{default:()=>f(go,null)}))}}),Uo=B({props:{clsPrefix:{type:String,required:!0},onClick:Function},render(){const{clsPrefix:e}=this;return f("div",{onClick:this.onClick,class:`${e}-layout-toggle-bar`},f("div",{class:`${e}-layout-toggle-bar__top`}),f("div",{class:`${e}-layout-toggle-bar__bottom`}))}}),Yo={position:Oe,bordered:Boolean,collapsedWidth:{type:Number,default:48},width:{type:[Number,String],default:272},contentStyle:{type:[String,Object],default:""},collapseMode:{type:String,default:"transform"},collapsed:{type:Boolean,default:void 0},defaultCollapsed:Boolean,showCollapsedContent:{type:Boolean,default:!0},showTrigger:{type:[Boolean,String],default:!1},nativeScrollbar:{type:Boolean,default:!0},inverted:Boolean,scrollbarProps:Object,triggerStyle:[String,Object],collapsedTriggerStyle:[String,Object],"onUpdate:collapsed":[Function,Array],onUpdateCollapsed:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,onExpand:[Function,Array],onCollapse:[Function,Array],onScroll:Function},qo=B({name:"LayoutSider",props:Object.assign(Object.assign({},Y.props),Yo),setup(e){const t=D(Ee),o=K(null),r=K(null),a=z(()=>de(s.value?e.collapsedWidth:e.width)),n=z(()=>e.collapseMode!=="transform"?{}:{minWidth:de(e.width)}),c=z(()=>t?t.siderPlacement:"left"),d=K(e.defaultCollapsed),s=ve(J(e,"collapsed"),d);function h(P,S){if(e.nativeScrollbar){const{value:R}=o;R&&(S===void 0?R.scrollTo(P):R.scrollTo(P,S))}else{const{value:R}=r;R&&R.scrollTo(P,S)}}function p(){const{"onUpdate:collapsed":P,onUpdateCollapsed:S,onExpand:R,onCollapse:_}=e,{value:I}=s;S&&E(S,!I),P&&E(P,!I),d.value=!I,I?R&&E(R):_&&E(_)}let b=0,u=0;const H=P=>{var S;const R=P.target;b=R.scrollLeft,u=R.scrollTop,(S=e.onScroll)===null||S===void 0||S.call(e,P)};He(()=>{if(e.nativeScrollbar){const P=o.value;P&&(P.scrollTop=u,P.scrollLeft=b)}}),q(Fe,{collapsedRef:s,collapseModeRef:J(e,"collapseMode")});const{mergedClsPrefixRef:k,inlineThemeDisabled:y}=ne(e),g=Y("Layout","-layout-sider",Ko,Be,e,k);function w(P){var S,R;P.propertyName==="max-width"&&(s.value?(S=e.onAfterLeave)===null||S===void 0||S.call(e):(R=e.onAfterEnter)===null||R===void 0||R.call(e))}const F={scrollTo:h},V=z(()=>{const{common:{cubicBezierEaseInOut:P},self:S}=g.value,{siderToggleButtonColor:R,siderToggleButtonBorder:_,siderToggleBarColor:I,siderToggleBarColorHover:i}=S,x={"--n-bezier":P,"--n-toggle-button-color":R,"--n-toggle-button-border":_,"--n-toggle-bar-color":I,"--n-toggle-bar-color-hover":i};return e.inverted?(x["--n-color"]=S.siderColorInverted,x["--n-text-color"]=S.textColorInverted,x["--n-border-color"]=S.siderBorderColorInverted,x["--n-toggle-button-icon-color"]=S.siderToggleButtonIconColorInverted,x.__invertScrollbar=S.__invertScrollbar):(x["--n-color"]=S.siderColor,x["--n-text-color"]=S.textColor,x["--n-border-color"]=S.siderBorderColor,x["--n-toggle-button-icon-color"]=S.siderToggleButtonIconColor),x}),O=y?ie("layout-sider",z(()=>e.inverted?"a":"b"),V,e):void 0;return Object.assign({scrollableElRef:o,scrollbarInstRef:r,mergedClsPrefix:k,mergedTheme:g,styleMaxWidth:a,mergedCollapsed:s,scrollContainerStyle:n,siderPlacement:c,handleNativeElScroll:H,handleTransitionend:w,handleTriggerClick:p,inlineThemeDisabled:y,cssVars:V,themeClass:O==null?void 0:O.themeClass,onRender:O==null?void 0:O.onRender},F)},render(){var e;const{mergedClsPrefix:t,mergedCollapsed:o,showTrigger:r}=this;return(e=this.onRender)===null||e===void 0||e.call(this),f("aside",{class:[`${t}-layout-sider`,this.themeClass,`${t}-layout-sider--${this.position}-positioned`,`${t}-layout-sider--${this.siderPlacement}-placement`,this.bordered&&`${t}-layout-sider--bordered`,o&&`${t}-layout-sider--collapsed`,(!o||this.showCollapsedContent)&&`${t}-layout-sider--show-content`],onTransitionend:this.handleTransitionend,style:[this.inlineThemeDisabled?void 0:this.cssVars,{maxWidth:this.styleMaxWidth,width:de(this.width)}]},this.nativeScrollbar?f("div",{class:`${t}-layout-sider-scroll-container`,onScroll:this.handleNativeElScroll,style:[this.scrollContainerStyle,{overflow:"auto"},this.contentStyle],ref:"scrollableElRef"},this.$slots):f(Ae,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",style:this.scrollContainerStyle,contentStyle:this.contentStyle,theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,builtinThemeOverrides:this.inverted&&this.cssVars.__invertScrollbar==="true"?{colorHover:"rgba(255, 255, 255, .4)",color:"rgba(255, 255, 255, .3)"}:void 0}),this.$slots),r?r==="bar"?f(Uo,{clsPrefix:t,style:o?this.collapsedTriggerStyle:this.triggerStyle,onClick:this.handleTriggerClick}):f(Do,{clsPrefix:t,style:o?this.collapsedTriggerStyle:this.triggerStyle,onClick:this.handleTriggerClick}):null,this.bordered?f("div",{class:`${t}-layout-sider__border`}):null)}}),ee=Z("n-menu"),fe=Z("n-submenu"),ge=Z("n-menu-item-group"),te=8;function be(e){const t=D(ee),{props:o,mergedCollapsedRef:r}=t,a=D(fe,null),n=D(ge,null),c=z(()=>o.mode==="horizontal"),d=z(()=>c.value?o.dropdownPlacement:"tmNodes"in e?"right-start":"right"),s=z(()=>{var u;return Math.max((u=o.collapsedIconSize)!==null&&u!==void 0?u:o.iconSize,o.iconSize)}),h=z(()=>{var u;return!c.value&&e.root&&r.value&&(u=o.collapsedIconSize)!==null&&u!==void 0?u:o.iconSize}),p=z(()=>{if(c.value)return;const{collapsedWidth:u,indent:H,rootIndent:k}=o,{root:y,isGroup:g}=e,w=k===void 0?H:k;if(y)return r.value?u/2-s.value/2:w;if(n)return H/2+n.paddingLeftRef.value;if(a)return(g?H/2:H)+a.paddingLeftRef.value}),b=z(()=>{const{collapsedWidth:u,indent:H,rootIndent:k}=o,{value:y}=s,{root:g}=e;return c.value||!g||!r.value?te:(k===void 0?H:k)+y+te-(u+y)/2});return{dropdownPlacement:d,activeIconSize:h,maxIconSize:s,paddingLeft:p,iconMarginRight:b,NMenu:t,NSubmenu:a}}const xe={internalKey:{type:[String,Number],required:!0},root:Boolean,isGroup:Boolean,level:{type:Number,required:!0},title:[String,Function],extra:[String,Function]},je=Object.assign(Object.assign({},xe),{tmNode:{type:Object,required:!0},tmNodes:{type:Array,required:!0}}),Go=B({name:"MenuOptionGroup",props:je,setup(e){q(fe,null);const t=be(e);q(ge,{paddingLeftRef:t.paddingLeft});const{mergedClsPrefixRef:o,props:r}=D(ee);return function(){const{value:a}=o,n=t.paddingLeft.value,{nodeProps:c}=r,d=c==null?void 0:c(e.tmNode.rawNode);return f("div",{class:`${a}-menu-item-group`,role:"group"},f("div",Object.assign({},d,{class:[`${a}-menu-item-group-title`,d==null?void 0:d.class],style:[(d==null?void 0:d.style)||"",n!==void 0?`padding-left: ${n}px;`:""]}),X(e.title),e.extra?f(le,null," ",X(e.extra)):null),f("div",null,e.tmNodes.map(s=>Ce(s,r))))}}}),Ve=B({name:"MenuOptionContent",props:{collapsed:Boolean,disabled:Boolean,title:[String,Function],icon:Function,extra:[String,Function],showArrow:Boolean,childActive:Boolean,hover:Boolean,paddingLeft:Number,selected:Boolean,maxIconSize:{type:Number,required:!0},activeIconSize:{type:Number,required:!0},iconMarginRight:{type:Number,required:!0},clsPrefix:{type:String,required:!0},onClick:Function,tmNode:{type:Object,required:!0}},setup(e){const{props:t}=D(ee);return{menuProps:t,style:z(()=>{const{paddingLeft:o}=e;return{paddingLeft:o&&`${o}px`}}),iconStyle:z(()=>{const{maxIconSize:o,activeIconSize:r,iconMarginRight:a}=e;return{width:`${o}px`,height:`${o}px`,fontSize:`${r}px`,marginRight:`${a}px`}})}},render(){const{clsPrefix:e,tmNode:t,menuProps:{renderIcon:o,renderLabel:r,renderExtra:a,expandIcon:n}}=this,c=o?o(t.rawNode):X(this.icon);return f("div",{onClick:d=>{var s;(s=this.onClick)===null||s===void 0||s.call(this,d)},role:"none",class:[`${e}-menu-item-content`,{[`${e}-menu-item-content--selected`]:this.selected,[`${e}-menu-item-content--collapsed`]:this.collapsed,[`${e}-menu-item-content--child-active`]:this.childActive,[`${e}-menu-item-content--disabled`]:this.disabled,[`${e}-menu-item-content--hover`]:this.hover}],style:this.style},c&&f("div",{class:`${e}-menu-item-content__icon`,style:this.iconStyle,role:"none"},[c]),f("div",{class:`${e}-menu-item-content-header`,role:"none"},r?r(t.rawNode):X(this.title),this.extra||a?f("span",{class:`${e}-menu-item-content-header__extra`}," ",a?a(t.rawNode):X(this.extra)):null),this.showArrow?f(ke,{ariaHidden:!0,class:`${e}-menu-item-content__arrow`,clsPrefix:e},{default:()=>n?n(t.rawNode):f(_o,null)}):null)}}),Ke=Object.assign(Object.assign({},xe),{rawNodes:{type:Array,default:()=>[]},tmNodes:{type:Array,default:()=>[]},tmNode:{type:Object,required:!0},disabled:{type:Boolean,default:!1},icon:Function,onClick:Function}),Wo=B({name:"Submenu",props:Ke,setup(e){const t=be(e),{NMenu:o,NSubmenu:r}=t,{props:a,mergedCollapsedRef:n,mergedThemeRef:c}=o,d=z(()=>{const{disabled:u}=e;return r!=null&&r.mergedDisabledRef.value||a.disabled?!0:u}),s=K(!1);q(fe,{paddingLeftRef:t.paddingLeft,mergedDisabledRef:d}),q(ge,null);function h(){const{onClick:u}=e;u&&u()}function p(){d.value||(n.value||o.toggleExpand(e.internalKey),h())}function b(u){s.value=u}return{menuProps:a,mergedTheme:c,doSelect:o.doSelect,inverted:o.invertedRef,isHorizontal:o.isHorizontalRef,mergedClsPrefix:o.mergedClsPrefixRef,maxIconSize:t.maxIconSize,activeIconSize:t.activeIconSize,iconMarginRight:t.iconMarginRight,dropdownPlacement:t.dropdownPlacement,dropdownShow:s,paddingLeft:t.paddingLeft,mergedDisabled:d,mergedValue:o.mergedValueRef,childActive:ue(()=>o.activePathRef.value.includes(e.internalKey)),collapsed:z(()=>a.mode==="horizontal"?!1:n.value?!0:!o.mergedExpandedKeysRef.value.includes(e.internalKey)),dropdownEnabled:z(()=>!d.value&&(a.mode==="horizontal"||n.value)),handlePopoverShowChange:b,handleClick:p}},render(){var e;const{mergedClsPrefix:t,menuProps:{renderIcon:o,renderLabel:r}}=this,a=()=>{const{isHorizontal:c,paddingLeft:d,collapsed:s,mergedDisabled:h,maxIconSize:p,activeIconSize:b,title:u,childActive:H,icon:k,handleClick:y,menuProps:{nodeProps:g},dropdownShow:w,iconMarginRight:F,tmNode:V,mergedClsPrefix:O}=this,P=g==null?void 0:g(V.rawNode);return f("div",Object.assign({},P,{class:[`${O}-menu-item`,P==null?void 0:P.class],role:"menuitem"}),f(Ve,{tmNode:V,paddingLeft:d,collapsed:s,disabled:h,iconMarginRight:F,maxIconSize:p,activeIconSize:b,title:u,extra:this.extra,showArrow:!c,childActive:H,clsPrefix:O,icon:k,hover:w,onClick:y}))},n=()=>f(eo,null,{default:()=>{const{tmNodes:c,collapsed:d}=this;return d?null:f("div",{class:`${t}-submenu-children`,role:"menu"},c.map(s=>Ce(s,this.menuProps)))}});return this.root?f(Te,Object.assign({size:"large"},(e=this.menuProps)===null||e===void 0?void 0:e.dropdownProps,{themeOverrides:this.mergedTheme.peerOverrides.Dropdown,theme:this.mergedTheme.peers.Dropdown,builtinThemeOverrides:{fontSizeLarge:"14px",optionIconSizeLarge:"18px"},value:this.mergedValue,trigger:"hover",disabled:!this.dropdownEnabled,placement:this.dropdownPlacement,keyField:this.menuProps.keyField,labelField:this.menuProps.labelField,childrenField:this.menuProps.childrenField,onUpdateShow:this.handlePopoverShowChange,options:this.rawNodes,onSelect:this.doSelect,inverted:this.inverted,renderIcon:o,renderLabel:r}),{default:()=>f("div",{class:`${t}-submenu`,role:"menuitem","aria-expanded":!this.collapsed},a(),this.isHorizontal?null:n())}):f("div",{class:`${t}-submenu`,role:"menuitem","aria-expanded":!this.collapsed},a(),n())}}),De=Object.assign(Object.assign({},xe),{tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function}),Xo=B({name:"MenuOption",props:De,setup(e){const t=be(e),{NSubmenu:o,NMenu:r}=t,{props:a,mergedClsPrefixRef:n,mergedCollapsedRef:c}=r,d=o?o.mergedDisabledRef:{value:!1},s=z(()=>d.value||e.disabled);function h(b){const{onClick:u}=e;u&&u(b)}function p(b){s.value||(r.doSelect(e.internalKey,e.tmNode.rawNode),h(b))}return{mergedClsPrefix:n,dropdownPlacement:t.dropdownPlacement,paddingLeft:t.paddingLeft,iconMarginRight:t.iconMarginRight,maxIconSize:t.maxIconSize,activeIconSize:t.activeIconSize,mergedTheme:r.mergedThemeRef,menuProps:a,dropdownEnabled:ue(()=>e.root&&c.value&&a.mode!=="horizontal"&&!s.value),selected:ue(()=>r.mergedValueRef.value===e.internalKey),mergedDisabled:s,handleClick:p}},render(){const{mergedClsPrefix:e,mergedTheme:t,tmNode:o,menuProps:{renderLabel:r,nodeProps:a}}=this,n=a==null?void 0:a(o.rawNode);return f("div",Object.assign({},n,{role:"menuitem",class:[`${e}-menu-item`,n==null?void 0:n.class]}),f(bo,{theme:t.peers.Tooltip,themeOverrides:t.peerOverrides.Tooltip,trigger:"hover",placement:this.dropdownPlacement,disabled:!this.dropdownEnabled||this.title===void 0,internalExtraClass:["menu-tooltip"]},{default:()=>r?r(o.rawNode):X(this.title),trigger:()=>f(Ve,{tmNode:o,clsPrefix:e,paddingLeft:this.paddingLeft,iconMarginRight:this.iconMarginRight,maxIconSize:this.maxIconSize,activeIconSize:this.activeIconSize,selected:this.selected,title:this.title,extra:this.extra,disabled:this.mergedDisabled,icon:this.icon,onClick:this.handleClick})}))}}),Zo=B({name:"MenuDivider",setup(){const e=D(ee),{mergedClsPrefixRef:t,isHorizontalRef:o}=e;return()=>o.value?null:f("div",{class:`${t.value}-menu-divider`})}}),Jo=he(je),Qo=he(De),et=he(Ke);function Ue(e){return e.type==="divider"||e.type==="render"}function ot(e){return e.type==="divider"}function Ce(e,t){const{rawNode:o}=e,{show:r}=o;if(r===!1)return null;if(Ue(o))return ot(o)?f(Zo,Object.assign({key:e.key},o.props)):null;const{labelField:a}=t,{key:n,level:c,isGroup:d}=e,s=Object.assign(Object.assign({},o),{title:o.title||o[a],extra:o.titleExtra||o.extra,key:n,internalKey:n,level:c,root:c===0,isGroup:d});return e.children?e.isGroup?f(Go,se(s,Jo,{tmNode:e,tmNodes:e.children,key:n})):f(Wo,se(s,et,{key:n,rawNodes:o[t.childrenField],tmNodes:e.children,tmNode:e})):f(Xo,se(s,Qo,{key:n,tmNode:e}))}const Ie=[C("&::before","background-color: var(--n-item-color-hover);"),v("arrow",`
 color: var(--n-arrow-color-hover);
 `),v("icon",`
 color: var(--n-item-icon-color-hover);
 `),m("menu-item-content-header",`
 color: var(--n-item-text-color-hover);
 `,[C("a",`
 color: var(--n-item-text-color-hover);
 `),v("extra",`
 color: var(--n-item-text-color-hover);
 `)])],we=[v("icon",`
 color: var(--n-item-icon-color-hover-horizontal);
 `),m("menu-item-content-header",`
 color: var(--n-item-text-color-hover-horizontal);
 `,[C("a",`
 color: var(--n-item-text-color-hover-horizontal);
 `),v("extra",`
 color: var(--n-item-text-color-hover-horizontal);
 `)])],tt=C([m("menu",`
 background-color: var(--n-color);
 color: var(--n-item-text-color);
 overflow: hidden;
 transition: background-color .3s var(--n-bezier);
 box-sizing: border-box;
 font-size: var(--n-font-size);
 padding-bottom: 6px;
 `,[A("horizontal",`
 display: inline-flex;
 padding-bottom: 0;
 `,[m("submenu","margin: 0;"),m("menu-item","margin: 0;"),m("menu-item-content",`
 padding: 0 20px;
 border-bottom: 2px solid #0000;
 `,[C("&::before","display: none;"),A("selected","border-bottom: 2px solid var(--n-border-color-horizontal)")]),m("menu-item-content",[A("selected",[v("icon","color: var(--n-item-icon-color-active-horizontal);"),m("menu-item-content-header",`
 color: var(--n-item-text-color-active-horizontal);
 `,[C("a","color: var(--n-item-text-color-active-horizontal);"),v("extra","color: var(--n-item-text-color-active-horizontal);")])]),A("child-active",`
 border-bottom: 2px solid var(--n-border-color-horizontal);
 `,[m("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-horizontal);
 `,[C("a",`
 color: var(--n-item-text-color-child-active-horizontal);
 `),v("extra",`
 color: var(--n-item-text-color-child-active-horizontal);
 `)]),v("icon",`
 color: var(--n-item-icon-color-child-active-horizontal);
 `)]),oe("disabled",[oe("selected, child-active",[C("&:focus-within",we)]),A("selected",[W(null,[v("icon","color: var(--n-item-icon-color-active-hover-horizontal);"),m("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover-horizontal);
 `,[C("a","color: var(--n-item-text-color-active-hover-horizontal);"),v("extra","color: var(--n-item-text-color-active-hover-horizontal);")])])]),A("child-active",[W(null,[v("icon","color: var(--n-item-icon-color-child-active-hover-horizontal);"),m("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover-horizontal);
 `,[C("a","color: var(--n-item-text-color-child-active-hover-horizontal);"),v("extra","color: var(--n-item-text-color-child-active-hover-horizontal);")])])]),W("border-bottom: 2px solid var(--n-border-color-horizontal);",we)]),m("menu-item-content-header",[C("a","color: var(--n-item-text-color-horizontal);")])])]),A("collapsed",[m("menu-item-content",[A("selected",[C("&::before",`
 background-color: var(--n-item-color-active-collapsed) !important;
 `)]),m("menu-item-content-header","opacity: 0;"),v("arrow","opacity: 0;"),v("icon","color: var(--n-item-icon-color-collapsed);")])]),m("menu-item",`
 height: var(--n-item-height);
 margin-top: 6px;
 position: relative;
 `),m("menu-item-content",`
 box-sizing: border-box;
 line-height: 1.75;
 height: 100%;
 display: grid;
 grid-template-areas: "icon content arrow";
 grid-template-columns: auto 1fr auto;
 align-items: center;
 cursor: pointer;
 position: relative;
 padding-right: 18px;
 transition:
 background-color .3s var(--n-bezier),
 padding-left .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[C("> *","z-index: 1;"),C("&::before",`
 z-index: auto;
 content: "";
 background-color: #0000;
 position: absolute;
 left: 8px;
 right: 8px;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),A("disabled",`
 opacity: .45;
 cursor: not-allowed;
 `),A("collapsed",[v("arrow","transform: rotate(0);")]),A("selected",[C("&::before","background-color: var(--n-item-color-active);"),v("arrow","color: var(--n-arrow-color-active);"),v("icon","color: var(--n-item-icon-color-active);"),m("menu-item-content-header",`
 color: var(--n-item-text-color-active);
 `,[C("a","color: var(--n-item-text-color-active);"),v("extra","color: var(--n-item-text-color-active);")])]),A("child-active",[m("menu-item-content-header",`
 color: var(--n-item-text-color-child-active);
 `,[C("a",`
 color: var(--n-item-text-color-child-active);
 `),v("extra",`
 color: var(--n-item-text-color-child-active);
 `)]),v("arrow",`
 color: var(--n-arrow-color-child-active);
 `),v("icon",`
 color: var(--n-item-icon-color-child-active);
 `)]),oe("disabled",[oe("selected, child-active",[C("&:focus-within",Ie)]),A("selected",[W(null,[v("arrow","color: var(--n-arrow-color-active-hover);"),v("icon","color: var(--n-item-icon-color-active-hover);"),m("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover);
 `,[C("a","color: var(--n-item-text-color-active-hover);"),v("extra","color: var(--n-item-text-color-active-hover);")])])]),A("child-active",[W(null,[v("arrow","color: var(--n-arrow-color-child-active-hover);"),v("icon","color: var(--n-item-icon-color-child-active-hover);"),m("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover);
 `,[C("a","color: var(--n-item-text-color-child-active-hover);"),v("extra","color: var(--n-item-text-color-child-active-hover);")])])]),A("selected",[W(null,[C("&::before","background-color: var(--n-item-color-active-hover);")])]),W(null,Ie)]),v("icon",`
 grid-area: icon;
 color: var(--n-item-icon-color);
 transition:
 color .3s var(--n-bezier),
 font-size .3s var(--n-bezier),
 margin-right .3s var(--n-bezier);
 box-sizing: content-box;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 `),v("arrow",`
 grid-area: arrow;
 font-size: 16px;
 color: var(--n-arrow-color);
 transform: rotate(180deg);
 opacity: 1;
 transition:
 color .3s var(--n-bezier),
 transform 0.2s var(--n-bezier),
 opacity 0.2s var(--n-bezier);
 `),m("menu-item-content-header",`
 grid-area: content;
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 opacity: 1;
 white-space: nowrap;
 overflow: hidden;
 text-overflow: ellipsis;
 color: var(--n-item-text-color);
 `,[C("a",`
 outline: none;
 text-decoration: none;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `,[C("&::before",`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),v("extra",`
 font-size: .93em;
 color: var(--n-group-text-color);
 transition: color .3s var(--n-bezier);
 `)])]),m("submenu",`
 cursor: pointer;
 position: relative;
 margin-top: 6px;
 `,[m("menu-item-content",`
 height: var(--n-item-height);
 `),m("submenu-children",`
 overflow: hidden;
 padding: 0;
 `,[oo({duration:".2s"})])]),m("menu-item-group",[m("menu-item-group-title",`
 margin-top: 6px;
 color: var(--n-group-text-color);
 cursor: default;
 font-size: .93em;
 height: 36px;
 display: flex;
 align-items: center;
 transition:
 padding-left .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)])]),m("menu-tooltip",[C("a",`
 color: inherit;
 text-decoration: none;
 `)]),m("menu-divider",`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 6px 18px;
 `)]);function W(e,t){return[A("hover",e,t),C("&:hover",e,t)]}const rt=Object.assign(Object.assign({},Y.props),{options:{type:Array,default:()=>[]},collapsed:{type:Boolean,default:void 0},collapsedWidth:{type:Number,default:48},iconSize:{type:Number,default:20},collapsedIconSize:{type:Number,default:24},rootIndent:Number,indent:{type:Number,default:32},labelField:{type:String,default:"label"},keyField:{type:String,default:"key"},childrenField:{type:String,default:"children"},disabledField:{type:String,default:"disabled"},defaultExpandAll:Boolean,defaultExpandedKeys:Array,expandedKeys:Array,value:[String,Number],defaultValue:{type:[String,Number],default:null},mode:{type:String,default:"vertical"},watchProps:{type:Array,default:void 0},disabled:Boolean,show:{type:Boolean,defalut:!0},inverted:Boolean,"onUpdate:expandedKeys":[Function,Array],onUpdateExpandedKeys:[Function,Array],onUpdateValue:[Function,Array],"onUpdate:value":[Function,Array],expandIcon:Function,renderIcon:Function,renderLabel:Function,renderExtra:Function,dropdownProps:Object,accordion:Boolean,nodeProps:Function,items:Array,onOpenNamesChange:[Function,Array],onSelect:[Function,Array],onExpandedNamesChange:[Function,Array],expandedNames:Array,defaultExpandedNames:Array,dropdownPlacement:{type:String,default:"bottom"}}),nt=B({name:"Menu",props:rt,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=ne(e),r=Y("Menu","-menu",tt,Fo,e,t),a=D(Fe,null),n=z(()=>{var _;const{collapsed:I}=e;if(I!==void 0)return I;if(a){const{collapseModeRef:i,collapsedRef:x}=a;if(i.value==="width")return(_=x.value)!==null&&_!==void 0?_:!1}return!1}),c=z(()=>{const{keyField:_,childrenField:I,disabledField:i}=e;return xo(e.items||e.options,{getIgnored(x){return Ue(x)},getChildren(x){return x[I]},getDisabled(x){return x[i]},getKey(x){var T;return(T=x[_])!==null&&T!==void 0?T:x.name}})}),d=z(()=>new Set(c.value.treeNodes.map(_=>_.key))),{watchProps:s}=e,h=K(null);s!=null&&s.includes("defaultValue")?ye(()=>{h.value=e.defaultValue}):h.value=e.defaultValue;const p=J(e,"value"),b=ve(p,h),u=K([]),H=()=>{u.value=e.defaultExpandAll?c.value.getNonLeafKeys():e.defaultExpandedNames||e.defaultExpandedKeys||c.value.getPath(b.value,{includeSelf:!1}).keyPath};s!=null&&s.includes("defaultExpandedKeys")?ye(H):H();const k=Co(e,["expandedNames","expandedKeys"]),y=ve(k,u),g=z(()=>c.value.treeNodes),w=z(()=>c.value.getPath(b.value).keyPath);q(ee,{props:e,mergedCollapsedRef:n,mergedThemeRef:r,mergedValueRef:b,mergedExpandedKeysRef:y,activePathRef:w,mergedClsPrefixRef:t,isHorizontalRef:z(()=>e.mode==="horizontal"),invertedRef:J(e,"inverted"),doSelect:F,toggleExpand:O});function F(_,I){const{"onUpdate:value":i,onUpdateValue:x,onSelect:T}=e;x&&E(x,_,I),i&&E(i,_,I),T&&E(T,_,I),h.value=_}function V(_){const{"onUpdate:expandedKeys":I,onUpdateExpandedKeys:i,onExpandedNamesChange:x,onOpenNamesChange:T}=e;I&&E(I,_),i&&E(i,_),x&&E(x,_),T&&E(T,_),u.value=_}function O(_){const I=Array.from(y.value),i=I.findIndex(x=>x===_);if(~i)I.splice(i,1);else{if(e.accordion&&d.value.has(_)){const x=I.findIndex(T=>d.value.has(T));x>-1&&I.splice(x,1)}I.push(_)}V(I)}const P=_=>{const I=c.value.getPath(_!=null?_:b.value,{includeSelf:!1}).keyPath;if(!I.length)return;const i=Array.from(y.value),x=new Set([...i,...I]);e.accordion&&d.value.forEach(T=>{x.has(T)&&!I.includes(T)&&x.delete(T)}),V(Array.from(x))},S=z(()=>{const{inverted:_}=e,{common:{cubicBezierEaseInOut:I},self:i}=r.value,{borderRadius:x,borderColorHorizontal:T,fontSize:Ye,itemHeight:qe,dividerColor:Ge}=i,l={"--n-divider-color":Ge,"--n-bezier":I,"--n-font-size":Ye,"--n-border-color-horizontal":T,"--n-border-radius":x,"--n-item-height":qe};return _?(l["--n-group-text-color"]=i.groupTextColorInverted,l["--n-color"]=i.colorInverted,l["--n-item-text-color"]=i.itemTextColorInverted,l["--n-item-text-color-hover"]=i.itemTextColorHoverInverted,l["--n-item-text-color-active"]=i.itemTextColorActiveInverted,l["--n-item-text-color-child-active"]=i.itemTextColorChildActiveInverted,l["--n-item-text-color-child-active-hover"]=i.itemTextColorChildActiveInverted,l["--n-item-text-color-active-hover"]=i.itemTextColorActiveHoverInverted,l["--n-item-icon-color"]=i.itemIconColorInverted,l["--n-item-icon-color-hover"]=i.itemIconColorHoverInverted,l["--n-item-icon-color-active"]=i.itemIconColorActiveInverted,l["--n-item-icon-color-active-hover"]=i.itemIconColorActiveHoverInverted,l["--n-item-icon-color-child-active"]=i.itemIconColorChildActiveInverted,l["--n-item-icon-color-child-active-hover"]=i.itemIconColorChildActiveHoverInverted,l["--n-item-icon-color-collapsed"]=i.itemIconColorCollapsedInverted,l["--n-item-text-color-horizontal"]=i.itemTextColorHorizontalInverted,l["--n-item-text-color-hover-horizontal"]=i.itemTextColorHoverHorizontalInverted,l["--n-item-text-color-active-horizontal"]=i.itemTextColorActiveHorizontalInverted,l["--n-item-text-color-child-active-horizontal"]=i.itemTextColorChildActiveHorizontalInverted,l["--n-item-text-color-child-active-hover-horizontal"]=i.itemTextColorChildActiveHoverHorizontalInverted,l["--n-item-text-color-active-hover-horizontal"]=i.itemTextColorActiveHoverHorizontalInverted,l["--n-item-icon-color-horizontal"]=i.itemIconColorHorizontalInverted,l["--n-item-icon-color-hover-horizontal"]=i.itemIconColorHoverHorizontalInverted,l["--n-item-icon-color-active-horizontal"]=i.itemIconColorActiveHorizontalInverted,l["--n-item-icon-color-active-hover-horizontal"]=i.itemIconColorActiveHoverHorizontalInverted,l["--n-item-icon-color-child-active-horizontal"]=i.itemIconColorChildActiveHorizontalInverted,l["--n-item-icon-color-child-active-hover-horizontal"]=i.itemIconColorChildActiveHoverHorizontalInverted,l["--n-arrow-color"]=i.arrowColorInverted,l["--n-arrow-color-hover"]=i.arrowColorHoverInverted,l["--n-arrow-color-active"]=i.arrowColorActiveInverted,l["--n-arrow-color-active-hover"]=i.arrowColorActiveHoverInverted,l["--n-arrow-color-child-active"]=i.arrowColorChildActiveInverted,l["--n-arrow-color-child-active-hover"]=i.arrowColorChildActiveHoverInverted,l["--n-item-color-hover"]=i.itemColorHoverInverted,l["--n-item-color-active"]=i.itemColorActiveInverted,l["--n-item-color-active-hover"]=i.itemColorActiveHoverInverted,l["--n-item-color-active-collapsed"]=i.itemColorActiveCollapsedInverted):(l["--n-group-text-color"]=i.groupTextColor,l["--n-color"]=i.color,l["--n-item-text-color"]=i.itemTextColor,l["--n-item-text-color-hover"]=i.itemTextColorHover,l["--n-item-text-color-active"]=i.itemTextColorActive,l["--n-item-text-color-child-active"]=i.itemTextColorChildActive,l["--n-item-text-color-child-active-hover"]=i.itemTextColorChildActiveHover,l["--n-item-text-color-active-hover"]=i.itemTextColorActiveHover,l["--n-item-icon-color"]=i.itemIconColor,l["--n-item-icon-color-hover"]=i.itemIconColorHover,l["--n-item-icon-color-active"]=i.itemIconColorActive,l["--n-item-icon-color-active-hover"]=i.itemIconColorActiveHover,l["--n-item-icon-color-child-active"]=i.itemIconColorChildActive,l["--n-item-icon-color-child-active-hover"]=i.itemIconColorChildActiveHover,l["--n-item-icon-color-collapsed"]=i.itemIconColorCollapsed,l["--n-item-text-color-horizontal"]=i.itemTextColorHorizontal,l["--n-item-text-color-hover-horizontal"]=i.itemTextColorHoverHorizontal,l["--n-item-text-color-active-horizontal"]=i.itemTextColorActiveHorizontal,l["--n-item-text-color-child-active-horizontal"]=i.itemTextColorChildActiveHorizontal,l["--n-item-text-color-child-active-hover-horizontal"]=i.itemTextColorChildActiveHoverHorizontal,l["--n-item-text-color-active-hover-horizontal"]=i.itemTextColorActiveHoverHorizontal,l["--n-item-icon-color-horizontal"]=i.itemIconColorHorizontal,l["--n-item-icon-color-hover-horizontal"]=i.itemIconColorHoverHorizontal,l["--n-item-icon-color-active-horizontal"]=i.itemIconColorActiveHorizontal,l["--n-item-icon-color-active-hover-horizontal"]=i.itemIconColorActiveHoverHorizontal,l["--n-item-icon-color-child-active-horizontal"]=i.itemIconColorChildActiveHorizontal,l["--n-item-icon-color-child-active-hover-horizontal"]=i.itemIconColorChildActiveHoverHorizontal,l["--n-arrow-color"]=i.arrowColor,l["--n-arrow-color-hover"]=i.arrowColorHover,l["--n-arrow-color-active"]=i.arrowColorActive,l["--n-arrow-color-active-hover"]=i.arrowColorActiveHover,l["--n-arrow-color-child-active"]=i.arrowColorChildActive,l["--n-arrow-color-child-active-hover"]=i.arrowColorChildActiveHover,l["--n-item-color-hover"]=i.itemColorHover,l["--n-item-color-active"]=i.itemColorActive,l["--n-item-color-active-hover"]=i.itemColorActiveHover,l["--n-item-color-active-collapsed"]=i.itemColorActiveCollapsed),l}),R=o?ie("menu",z(()=>e.inverted?"a":"b"),S,e):void 0;return{mergedClsPrefix:t,controlledExpandedKeys:k,uncontrolledExpanededKeys:u,mergedExpandedKeys:y,uncontrolledValue:h,mergedValue:b,activePath:w,tmNodes:g,mergedTheme:r,mergedCollapsed:n,cssVars:o?void 0:S,themeClass:R==null?void 0:R.themeClass,onRender:R==null?void 0:R.onRender,showOption:P}},render(){const{mergedClsPrefix:e,mode:t,themeClass:o,onRender:r}=this;return r==null||r(),f("div",{role:t==="horizontal"?"menubar":"menu",class:[`${e}-menu`,o,`${e}-menu--${t}`,this.mergedCollapsed&&`${e}-menu--collapsed`],style:this.cssVars},this.tmNodes.map(a=>Ce(a,this.$props)))}}),it={__name:"BreadCrumb",setup(e){const t=ae(),o=Re();function r(n){n!==o.path&&t.push(n)}function a(n){return n!=null&&n.customIcon?Le(n.customIcon,{size:18}):n!=null&&n.icon?re(n.icon,{size:18}):null}return(n,c)=>{const d=$o,s=Ao;return $(),L(s,null,{default:U(()=>[($(!0),G(le,null,to(N(o).matched.filter(h=>{var p;return!!((p=h.meta)!=null&&p.title)}),h=>($(),L(d,{key:h.path,onClick:p=>r(h.path)},{default:U(()=>[($(),L(Pe(a(h.meta)))),ro(" "+pe(h.meta.title),1)]),_:2},1032,["onClick"]))),128))]),_:1})}}},lt={class:"inline-block",preserveAspectRatio:"xMidYMid meet",viewBox:"0 0 24 24",width:"1em",height:"1em"},at=M("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M3 21h18v-2H3m0-7l4 4V8m4 9h10v-2H11v2Z"},null,-1),ct=[at];function st(e,t){return $(),G("svg",lt,ct)}const dt={name:"mdi-format-indent-decrease",render:st},ut={class:"inline-block",preserveAspectRatio:"xMidYMid meet",viewBox:"0 0 24 24",width:"1em",height:"1em"},vt=M("path",{fill:"currentColor",d:"M11 13h10v-2H11m0-2h10V7H11M3 3v2h18V3M11 17h10v-2H11M3 8v8l4-4m-4 9h18v-2H3v2Z"},null,-1),mt=[vt];function ht(e,t){return $(),G("svg",ut,mt)}const pt={name:"mdi-format-indent-increase",render:ht},ft={__name:"MenuCollapse",setup(e){const t=Q();return(o,r)=>{const a=pt,n=dt,c=Ne;return $(),L(c,{size:"20","cursor-pointer":"",onClick:N(t).switchCollapsed},{default:U(()=>[N(t).collapsed?($(),L(a,{key:0})):($(),L(n,{key:1}))]),_:1},8,["onClick"])}}},gt={class:"inline-block",preserveAspectRatio:"xMidYMid meet",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},bt=M("path",{fill:"currentColor",d:"m290 236.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L169 160c-5.1-.6-9.5 3.7-8.9 8.9L179 329.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L370 423.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3L290 236.4zm352.7 187.3c3.1 3.1 8.2 3.1 11.3 0l133.7-133.6l43.7 43.7a8.01 8.01 0 0 0 13.6-4.7L863.9 169c.6-5.1-3.7-9.5-8.9-8.9L694.8 179c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L600.3 370a8.03 8.03 0 0 0 0 11.3l42.4 42.4zM845 694.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L654 600.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L734 787.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L855 864c5.1.6 9.5-3.7 8.9-8.9L845 694.9zm-463.7-94.6a8.03 8.03 0 0 0-11.3 0L236.3 733.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L160.1 855c-.6 5.1 3.7 9.5 8.9 8.9L329.2 845c6.6-.8 9.4-8.9 4.7-13.6L290 787.6L423.7 654c3.1-3.1 3.1-8.2 0-11.3l-42.4-42.4z"},null,-1),xt=[bt];function Ct(e,t){return $(),G("svg",gt,xt)}const _t={name:"ant-design-fullscreen-outlined",render:Ct},yt={class:"inline-block",preserveAspectRatio:"xMidYMid meet",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},zt=M("path",{fill:"currentColor",d:"M391 240.9c-.8-6.6-8.9-9.4-13.6-4.7l-43.7 43.7L200 146.3a8.03 8.03 0 0 0-11.3 0l-42.4 42.3a8.03 8.03 0 0 0 0 11.3L280 333.6l-43.9 43.9a8.01 8.01 0 0 0 4.7 13.6L401 410c5.1.6 9.5-3.7 8.9-8.9L391 240.9zm10.1 373.2L240.8 633c-6.6.8-9.4 8.9-4.7 13.6l43.9 43.9L146.3 824a8.03 8.03 0 0 0 0 11.3l42.4 42.3c3.1 3.1 8.2 3.1 11.3 0L333.7 744l43.7 43.7A8.01 8.01 0 0 0 391 783l18.9-160.1c.6-5.1-3.7-9.4-8.8-8.8zm221.8-204.2L783.2 391c6.6-.8 9.4-8.9 4.7-13.6L744 333.6L877.7 200c3.1-3.1 3.1-8.2 0-11.3l-42.4-42.3a8.03 8.03 0 0 0-11.3 0L690.3 279.9l-43.7-43.7a8.01 8.01 0 0 0-13.6 4.7L614.1 401c-.6 5.2 3.7 9.5 8.8 8.9zM744 690.4l43.9-43.9a8.01 8.01 0 0 0-4.7-13.6L623 614c-5.1-.6-9.5 3.7-8.9 8.9L633 783.1c.8 6.6 8.9 9.4 13.6 4.7l43.7-43.7L824 877.7c3.1 3.1 8.2 3.1 11.3 0l42.4-42.3c3.1-3.1 3.1-8.2 0-11.3L744 690.4z"},null,-1),It=[zt];function wt(e,t){return $(),G("svg",yt,It)}const St={name:"ant-design-fullscreen-exit-outlined",render:wt},Ht={__name:"FullScreen",setup(e){const{isFullscreen:t,toggle:o}=no();return(r,a)=>{const n=St,c=_t,d=Ne;return $(),L(d,{mr20:"",size:"18",style:{cursor:"pointer"},onClick:N(o)},{default:U(()=>[N(t)?($(),L(n,{key:0})):($(),L(c,{key:1}))]),_:1},8,["onClick"])}}},At="/shiqi/assets/avatar.f26d565a.svg",kt={flex:"","items-center":"","cursor-pointer":""},Rt=M("img",{src:At,mr10:"","w-35":"","h-35":"","rounded-full":""},null,-1),Pt={__name:"UserAvatar",setup(e){const t=ae(),o=io(),r=[{label:"\u9000\u51FA\u767B\u5F55",key:"logout",icon:re("mdi:exit-to-app",{size:"14px"})},{label:"\u4FEE\u6539\u5BC6\u7801",key:"resetPwd",icon:re("mdi:lock-reset",{size:"14px"})}];function a(n){n==="logout"?$dialog.confirm({title:"\u63D0\u793A",type:"info",content:"\u786E\u8BA4\u9000\u51FA\uFF1F",confirm(){o.logout(!0),$message.success("\u5DF2\u9000\u51FA\u767B\u5F55")}}):n==="resetPwd"&&t.push("/reset-pwd")}return(n,c)=>{const d=Te;return $(),L(d,{options:r,onSelect:a},{default:U(()=>[M("div",kt,[Rt,M("span",null,pe(N(o).name),1)])]),_:1})}}},$t={flex:"","items-center":""},Tt={"ml-auto":"",flex:"","items-center":""},Lt={__name:"index",setup(e){return(t,o)=>($(),G(le,null,[M("div",$t,[j(ft),j(it,{"ml-15":""})]),M("div",Tt,[j(Ht),j(Pt)])],64))}},Nt={class:"inline-block",width:"24",height:"24",viewBox:"0 0 48 48",fill:"none",xmlns:"http://www.w3.org/2000/svg"},Mt=lo('<path d="M12 33H4V7H44V33H36H12Z" fill="#316c72" stroke="#333" stroke-width="4" stroke-linejoin="round"></path><path d="M16 22V26" stroke="#FFF" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path><path d="M24 33V39" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path><path d="M24 18V26" stroke="#FFF" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path><path d="M32 14V26" stroke="#FFF" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 41H36" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></path>',6),Bt=[Mt];function Ft(e,t){return $(),G("svg",Nt,Bt)}const Ot={name:"custom-workbench",render:Ft},Et={__name:"SideLogo",setup(e){const t="\u4E16\u5947\u5546\u884C\u540E\u53F0\u7BA1\u7406",o=Q();return(r,a)=>{const n=Ot,c=$e("router-link");return $(),L(c,{"h-60":"","f-c-c":"",to:"/"},{default:U(()=>[j(n,{"text-36":"","color-primary":""}),ao(M("h2",{"ml-10":"","color-primary":"","text-16":"","font-bold":"","max-w-140":"","flex-shrink-0":""},pe(N(t)),513),[[co,!N(o).collapsed]])]),_:1})}}};const jt={__name:"SideMenu",setup(e){const t=ae(),o=Re(),r=so(),a=Q(),n=z(()=>r.menus.map(p=>d(p)).sort((p,b)=>p.order-b.order));function c(p,b){return ze(b)?b:"/"+[p,b].filter(u=>!!u&&u!=="/").map(u=>u.replace(/(^\/)|(\/$)/g,"")).join("/")}function d(p,b=""){var k,y;let u={label:p.meta&&p.meta.title||p.name,key:p.name,path:c(b,p.path),icon:s(p.meta),order:((k=p.meta)==null?void 0:k.order)||0};const H=p.children?p.children.filter(g=>g.name&&!g.isHidden):[];if(!H.length)return u;if(H.length===1){const g=H[0];u={label:((y=g.meta)==null?void 0:y.title)||g.name,key:g.name,path:c(u.path,g.path),icon:s(g.meta),order:u.order};const w=g.children?g.children.filter(F=>F.name&&!F.isHidden):[];w.length===1?u=d(w[0],u.path):w.length>1&&(u.children=w.map(F=>d(F,u.path)).sort((F,V)=>F.order-V.order))}else u.children=H.map(g=>d(g,u.path)).sort((g,w)=>g.order-w.order);return u}function s(p){return p!=null&&p.customIcon?Le(p.customIcon,{size:18}):p!=null&&p.icon?re(p.icon,{size:18}):null}function h(p,b){ze(b.path)?window.open(b.path):b.path===o.path?a.reloadPage():t.push(b.path)}return(p,b)=>{var H;const u=nt;return $(),L(u,{class:"side-menu",accordion:"",indent:18,"collapsed-icon-size":22,"collapsed-width":64,options:N(n),value:((H=N(o).meta)==null?void 0:H.activeMenu)||N(o).name,"onUpdate:value":h},null,8,["options","value"])}}},Vt={__name:"index",setup(e){return(t,o)=>($(),G(le,null,[j(Et),j(jt)],64))}},Kt={__name:"AppMain",setup(e){const t=Q(),r=ae().getRoutes(),a=z(()=>r.filter(n=>{var c;return(c=n.meta)==null?void 0:c.keepAlive}).map(n=>n.name));return(n,c)=>{const d=$e("router-view");return $(),L(d,null,{default:U(({Component:s,route:h})=>[($(),L(uo,{include:N(a)},[N(t).reloadFlag?($(),L(Pe(s),{key:N(t).aliveKeys[h.name]||h.fullPath})):vo("",!0)],1032,["include"]))]),_:1})}}};const Dt={"flex-1":"","flex-col":"","overflow-hidden":""},Ut={"flex-1":"","overflow-hidden":""},Xt={__name:"index",setup(e){const t=Q();return(o,r)=>{const a=qo,n=Vo;return $(),L(n,{"has-sider":"","wh-full":""},{default:U(()=>[j(a,{bordered:"","collapse-mode":"width","collapsed-width":64,width:220,"native-scrollbar":!1,collapsed:N(t).collapsed},{default:U(()=>[j(Vt)]),_:1},8,["collapsed"]),M("article",Dt,[M("header",{"bg-white":"","px-15":"","border-b":"","bc-eee":"",flex:"","items-center":"",style:mo(`height: ${N(ho).height}px`)},[j(Lt)],4),M("section",Ut,[j(Kt)])])]),_:1})}}};export{Xt as default};
